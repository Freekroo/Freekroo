import React from "react";

function BesasFiltre() {
  return (
    <div>
      <div class="col-md-12 pb-2 pt-2">
        <select
          name="test"
          class="form-control col-xs-offset-4 col-md-offset-4"
          onchange="if (this.value) window.location.href=this.value"
          style="width:30%;"
        >
          <option value="/bayiharita/">Tümü</option>{" "}
          <option value="iletisim.php?bayiHarita=1&amp;ilce=Gemlik">
            Gemlik
          </option>
          <option value="iletisim.php?bayiHarita=1&amp;ilce=Nilüfer">
            Nilüfer
          </option>
          <option value="iletisim.php?bayiHarita=1&amp;ilce=Osmangazi">
            Osmangazi
          </option>
          <option value="iletisim.php?bayiHarita=1&amp;ilce=Yıldırım">
            Yıldırım
          </option>
          <option value="iletisim.php?bayiHarita=1&amp;ilce=Gürsu">
            Gürsu
          </option>
          <option value="iletisim.php?bayiHarita=1&amp;ilce=İnegöl">
            İnegöl
          </option>
          <option value="iletisim.php?bayiHarita=1&amp;ilce=Kestel">
            Kestel
          </option>
          <option value="iletisim.php?bayiHarita=1&amp;ilce=Mudanya">
            Mudanya
          </option>
        </select>
      </div>
    </div>
  );
}

export default BesasFiltre;
