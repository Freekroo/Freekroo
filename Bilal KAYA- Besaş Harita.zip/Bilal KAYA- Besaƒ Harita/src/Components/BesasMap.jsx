import "./BesasMapDesign.css";
import React from "react";
import { MapContainer, TileLayer, Marker,Popup } from "react-leaflet";
import besasData from "./besasloc.json";
import "leaflet/dist/leaflet.css";




function BesasMap() {

  
  return (
    <MapContainer center={[40.19314004794457, 29.0770136]} zoom={13} scrollWheelZoom={true}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      {besasData.map((bsas) => (
        <Marker 
        key={bsas.gml_id}
        position={bsas.geojson.coordinates}></Marker>
      ))}
    </MapContainer>
  );
}

export default BesasMap;
